class AppConstants {
  static const String appVersion = '1.6.0';
  static const String repoUrl = 'https://github.com/SaadhJawwadh/Note-taking';
  static const String releaseUrl = '$repoUrl/releases';
}
