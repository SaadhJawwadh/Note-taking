import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'note_model.dart';
import 'dart:convert';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('notes.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 4,
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE notes (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        dateCreated TEXT NOT NULL,
        dateModified TEXT NOT NULL,
        color INTEGER NOT NULL,
        isPinned INTEGER NOT NULL,
        isArchived INTEGER NOT NULL DEFAULT 0,
        imagePath TEXT,
        category TEXT,
        tags TEXT,
        deletedAt TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE tags (
        name TEXT PRIMARY KEY,
        color INTEGER NOT NULL
      )
    ''');
  }

  Future _upgradeDB(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
          'ALTER TABLE notes ADD COLUMN isArchived INTEGER NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE notes ADD COLUMN deletedAt TEXT');
    }
    if (oldVersion < 3) {
      await db.execute('ALTER TABLE notes ADD COLUMN tags TEXT');
    }
    if (oldVersion < 4) {
      await db.execute('''
        CREATE TABLE tags (
          name TEXT PRIMARY KEY,
          color INTEGER NOT NULL
        )
      ''');
    }
  }

  Future<void> createNote(Note note) async {
    final db = await instance.database;
    await db.insert('notes', note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<Note?> readNote(String id) async {
    final db = await instance.database;
    final maps = await db.query(
      'notes',
      columns: [
        'id',
        'title',
        'content',
        'dateCreated',
        'dateModified',
        'color',
        'isPinned',
        'isArchived',
        'imagePath',
        'category',
        'tags',
        'deletedAt'
      ],
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Note.fromMap(maps.first);
    } else {
      return null;
    }
  }

  Future<List<Note>> readAllNotes() async {
    final db = await instance.database;
    final result = await db.query('notes',
        where: 'deletedAt IS NULL',
        orderBy: 'isPinned DESC, dateModified DESC');

    return result.map((json) => Note.fromMap(json)).toList();
  }

  Future<List<Note>> searchNotes(String keyword) async {
    final db = await instance.database;
    final result = await db.query(
      'notes',
      where:
          '(title LIKE ? OR content LIKE ? OR tags LIKE ?) AND deletedAt IS NULL',
      whereArgs: ['%$keyword%', '%$keyword%', '%$keyword%'],
      orderBy: 'dateModified DESC',
    );
    return result.map((json) => Note.fromMap(json)).toList();
  }

  Future<List<Note>> readArchivedNotes() async {
    final db = await instance.database;
    final result = await db.query('notes',
        where: 'isArchived = 1 AND deletedAt IS NULL',
        orderBy: 'dateModified DESC');
    return result.map((json) => Note.fromMap(json)).toList();
  }

  Future<int> updateNote(Note note) async {
    final db = await instance.database;
    return db.update(
      'notes',
      note.toMap(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<int> deleteNote(String id) async {
    final db = await instance.database;
    return await db.delete(
      'notes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> archiveNote(String id, bool archive) async {
    final db = await instance.database;
    return await db.update(
      'notes',
      {'isArchived': archive ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Note>> readNotesByCategory(String category) async {
    final db = await instance.database;
    final result = await db.query('notes',
        where: 'category = ? AND deletedAt IS NULL AND isArchived = 0',
        whereArgs: [category],
        orderBy: 'dateModified DESC');
    return result.map((json) => Note.fromMap(json)).toList();
  }

  Future<List<String>> getAllTags() async {
    final db = await instance.database;
    final result = await db.query(
      'notes',
      columns: ['tags'],
      where: 'deletedAt IS NULL',
    );

    final Set<String> allTags = {};
    for (var row in result) {
      if (row['tags'] != null) {
        try {
          final List<dynamic> tags = jsonDecode(row['tags'] as String);
          allTags.addAll(tags.map((e) => e.toString()));
        } catch (e) {
          // Ignore invalid JSON
        }
      }
    }
    return allTags.toList()..sort();
  }

  Future<Map<String, int>> getAllTagColors() async {
    final db = await instance.database;
    final result = await db.query('tags');
    return {for (var e in result) e['name'] as String: e['color'] as int};
  }

  Future<int?> getTagColor(String tagName) async {
    final db = await instance.database;
    final result = await db.query('tags',
        columns: ['color'], where: 'name = ?', whereArgs: [tagName]);
    if (result.isNotEmpty) {
      return result.first['color'] as int;
    }
    return null;
  }

  Future<void> setTagColor(String tagName, int color) async {
    final db = await instance.database;
    await db.insert(
      'tags',
      {'name': tagName, 'color': color},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> renameTag(String oldTag, String newTag) async {
    final db = await instance.database;
    // Update notes
    final notes = await readAllNotes();
    for (var note in notes) {
      if (note.tags.contains(oldTag)) {
        final updatedTags = List<String>.from(note.tags);
        final index = updatedTags.indexOf(oldTag);
        if (index != -1) {
          updatedTags[index] = newTag;
          updatedTags.sort();
          await updateNote(note.copyWith(tags: updatedTags));
        }
      }
    }

    // Update color entry if exists
    final color = await getTagColor(oldTag);
    if (color != null) {
      await setTagColor(newTag, color);
      await db.delete('tags', where: 'name = ?', whereArgs: [oldTag]);
    }
  }

  Future<void> deleteTag(String tag) async {
    final db = await instance.database;
    // Update notes
    final notes = await readAllNotes();
    for (var note in notes) {
      if (note.tags.contains(tag)) {
        final updatedTags = List<String>.from(note.tags);
        updatedTags.remove(tag);
        await updateNote(note.copyWith(tags: updatedTags));
      }
    }
    // Delete color entry
    await db.delete('tags', where: 'name = ?', whereArgs: [tag]);
  }
}
