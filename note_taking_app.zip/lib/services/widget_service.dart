import 'package:home_widget/home_widget.dart';
import '../data/note_model.dart';
import 'package:flutter/foundation.dart';

class WidgetService {
  static Future<void> updateWidget(Note note) async {
    try {
      await HomeWidget.saveWidgetData<String>(
          'title', note.title.isEmpty ? 'Untitled' : note.title);
      await HomeWidget.saveWidgetData<String>(
          'message', note.content.isNotEmpty ? note.content : 'No content');
      await HomeWidget.updateWidget(
        name: 'HomeWidgetProvider',
        androidName: 'HomeWidgetProvider',
      );
    } catch (e) {
      debugPrint("Error updating widget: $e");
    }
  }
}
