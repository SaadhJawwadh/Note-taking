import 'package:file_picker/file_picker.dart';

class FilePickerWindows extends FilePicker {
  /// Errors on attempted instantiation of the stub. It exists only to satisfy
  /// compile-time dependencies, and should never actually be created.
  FilePickerWindows() : assert(false);
}
