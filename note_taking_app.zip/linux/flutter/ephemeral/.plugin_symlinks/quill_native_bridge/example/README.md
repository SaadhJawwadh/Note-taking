# 🪶 Quill Native Bridge Example

Demonstrates the usage of [`quill_native_bridge`](https://pub.dev/packages/quill_native_bridge) plugin.

Refer to [example_test.dart](./test/example_test.dart) for a minimal example of mocking `QuillNativeBridge` for tests.