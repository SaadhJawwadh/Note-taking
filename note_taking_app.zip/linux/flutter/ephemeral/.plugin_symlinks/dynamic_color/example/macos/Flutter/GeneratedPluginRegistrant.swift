//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import dynamic_color

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  DynamicColorPlugin.register(with: registry.registrar(forPlugin: "DynamicColorPlugin"))
}
