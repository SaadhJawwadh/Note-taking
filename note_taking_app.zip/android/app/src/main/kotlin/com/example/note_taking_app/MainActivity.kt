package com.example.note_taking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
